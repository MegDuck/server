import platform
import os

os.system("mkdir tmp")
os.system("cd tmp")
os.system("mv curl.tar.gz")
os.system("tar -xvf curl.tar.gz")
os.system("mv curl-7.76.1/* .")
os.system("mkdir out")
os.system("./configure --with-openssl --prefix=./out")
os.system("make && make test")
os.system("make install")

